//
//  AnchorFrameViewController.swift
//  LearnSwift
//
//  Created by Mailavan on 01/02/19.
//  Copyright © 2019 Karthik Baskaran. All rights reserved.
//

import UIKit

class AnchorFrameViewController: UIViewController , UITableViewDelegate, UITableViewDataSource
{
    
    var tblView:UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.view.backgroundColor=UIColor.white
        
        tblView=UITableView ()
        tblView.backgroundColor=UIColor.clear
        tblView.translatesAutoresizingMaskIntoConstraints=false
        tblView.register(AnchorFrameTableViewCell.self, forCellReuseIdentifier: "cell")
        tblView.separatorColor=UIColor.clear
        tblView.delegate=self
        tblView.dataSource=self
        tblView.showsVerticalScrollIndicator=false
        tblView.rowHeight = UITableView.automaticDimension
        tblView.showsHorizontalScrollIndicator=false
        tblView.separatorStyle = .none
        self.view.addSubview(tblView)
        
        
        tblView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0).isActive=true
        tblView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive=true
        tblView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive=true
        tblView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0).isActive=true
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableView.automaticDimension

    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AnchorFrameTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AnchorFrameTableViewCell

        
        cell.Lbl1.text=String(format:"Dummy Content Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", arguments: [indexPath.row])
        
        cell.Lbl2.text=String(format:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", arguments: [indexPath.row])

        cell.Lbl3.text=String(format:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum." , arguments: [indexPath.row])
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}
