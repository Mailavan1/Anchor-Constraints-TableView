//
//  AnchorFrameTableViewCell.swift
//  LearnSwift
//
//  Created by Mailavan on 01/02/19.
//  Copyright © 2019 Karthik Baskaran. All rights reserved.
//

import UIKit

class AnchorFrameTableViewCell: UITableViewCell {

    var backView: UIView!
    var Lbl1 : UILabel!
    var Lbl2 : UILabel!
    var Lbl3 : UILabel!

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?)
    {
        super .init(style: style, reuseIdentifier: reuseIdentifier)
        createDesign()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func createDesign ()
    {
        backView=UIView()
        backView.backgroundColor=UIColor.clear
        backView.translatesAutoresizingMaskIntoConstraints=false
        backView.layer.borderWidth=1.0
        backView.layer.borderColor=UIColor.lightGray.cgColor
        contentView.addSubview(backView)

        Lbl1=UILabel()
        Lbl1.backgroundColor=UIColor.clear
        Lbl1.translatesAutoresizingMaskIntoConstraints=false
        Lbl1.font=UIFont.systemFont(ofSize: 10)
        Lbl1.numberOfLines=0
        Lbl1.lineBreakMode = .byWordWrapping
        backView.addSubview(Lbl1)
        
        Lbl2=UILabel()
        Lbl2.backgroundColor=UIColor.clear
        Lbl2.translatesAutoresizingMaskIntoConstraints=false
        Lbl2.font=UIFont.systemFont(ofSize: 10)
        Lbl2.numberOfLines=0
        Lbl2.lineBreakMode = .byWordWrapping
        backView.addSubview(Lbl2)
        
        Lbl3=UILabel()
        Lbl3.backgroundColor=UIColor.clear
        Lbl3.translatesAutoresizingMaskIntoConstraints=false
        Lbl3.font=UIFont.systemFont(ofSize: 10)
        Lbl3.numberOfLines=0
        Lbl3.lineBreakMode = .byWordWrapping
        backView.addSubview(Lbl3)

        
        setupConstraints()
    }

    
    func setupConstraints ()
    {
        
        backView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10).isActive=true
        backView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10).isActive=true
        backView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5).isActive=true
        backView.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -5).isActive=true
        
        Lbl1.leadingAnchor.constraint(equalTo: backView.leadingAnchor, constant: 10).isActive=true
        Lbl1.topAnchor.constraint(equalTo: backView.topAnchor, constant: 5).isActive=true
        Lbl1.trailingAnchor.constraint(equalTo: backView.trailingAnchor, constant: -10).isActive=true
        Lbl1.bottomAnchor.constraint(equalTo: Lbl2.topAnchor, constant: -15).isActive=true
        
        Lbl2.leadingAnchor.constraint(equalTo: Lbl1.leadingAnchor, constant: 0).isActive=true
        Lbl2.topAnchor.constraint(equalTo: Lbl1.bottomAnchor, constant: 0).isActive=true
        Lbl2.trailingAnchor.constraint(equalTo: Lbl1.trailingAnchor, constant: 0).isActive=true
        Lbl2.bottomAnchor.constraint(equalTo: Lbl3.topAnchor, constant: -15).isActive=true

        Lbl3.leadingAnchor.constraint(equalTo: Lbl2.leadingAnchor, constant: 0).isActive=true
        Lbl3.topAnchor.constraint(equalTo: Lbl2.bottomAnchor, constant: 0).isActive=true
        Lbl3.trailingAnchor.constraint(equalTo: Lbl2.trailingAnchor, constant: 0).isActive=true
        Lbl3.bottomAnchor.constraint(equalTo: backView.bottomAnchor, constant: -15).isActive=true
        
    }
    
    
}
